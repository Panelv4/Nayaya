from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import json, sqlite3, uuid, datetime, os, re
from urllib.parse import urlparse
from threading import Lock

ROOT=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(ROOT,'workbench.sqlite3')
LOCK=Lock()

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def db():
 c=sqlite3.connect(DB,timeout=10); c.row_factory=sqlite3.Row; return c

def init():
 with db() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS assessments(id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL, result TEXT NOT NULL, review_status TEXT NOT NULL, review_note TEXT NOT NULL DEFAULT ''); CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, event TEXT NOT NULL, assessment_id TEXT, details TEXT NOT NULL);''')

FACTS=[
 {'key':'age','label':'Age at application','type':'number','question':'What is the applicant’s age on the application date?','description':'Must be at least 18 years.'},
 {'key':'state','label':'State of residence','type':'text','question':'Which state does the applicant live in?','description':'Must be Madhya Pradesh.'},
 {'key':'income','label':'Annual household income','type':'number','question':'What is the annual household income in INR?','description':'Must be ₹3,00,000 or less.'},
 {'key':'identity','label':'Identity verification','type':'boolean','question':'Has identity been verified by the relevant authority?','description':'Identity must be verified.'},
 {'key':'disqualified','label':'Disqualification applies','type':'boolean','question':'Does the fictional disqualification apply?','description':'An established disqualification bars eligibility.'}
]
RULES=[
 {'id':'DEMO-01','name':'Minimum age','source':'Fictional Scheme, § 3(a)','expression':'age >= 18','category':'Condition'},
 {'id':'DEMO-02','name':'State residence','source':'Fictional Scheme, § 3(b)','expression':'state == Madhya Pradesh','category':'Condition'},
 {'id':'DEMO-03','name':'Income threshold','source':'Fictional Scheme, § 3(c)','expression':'income <= INR 300,000','category':'Condition'},
 {'id':'DEMO-04','name':'Identity verification','source':'Fictional Scheme, § 3(d)','expression':'identity == verified','category':'Condition'},
 {'id':'DEMO-05','name':'Disqualification exception','source':'Fictional Scheme, § 4','expression':'disqualified == false','category':'Exception'}
]

def evaluate(body):
 raw=body.get('facts',{})
 if not isinstance(raw,dict): raise ValueError('Facts must be an object.')
 facts={}; trace=[]; missing=[]; disputed=[]
 for f,r in zip(FACTS,RULES):
  key=f['key']; a=raw.get(key,{}); a=a if isinstance(a,dict) else {'value':a}; value=a.get('value'); status=a.get('status','user_asserted')
  if status not in ('user_asserted','disputed'): raise ValueError('Invalid fact status.')
  if value in ('',None): value=None
  if value is not None:
   if f['type']=='number':
    if isinstance(value,bool): raise ValueError('Invalid '+f['label'])
    try: value=float(value)
    except (ValueError,TypeError): raise ValueError('Invalid '+f['label'])
    if not 0 <= value <= (130 if key=='age' else 100000000000): raise ValueError('Invalid '+f['label'])
    if key=='age' and not value.is_integer(): raise ValueError('Age must be a whole number.')
   elif f['type']=='boolean':
    if not isinstance(value,bool): raise ValueError('Invalid '+f['label'])
   elif not isinstance(value,str) or len(value)>100: raise ValueError('Invalid '+f['label'])
  facts[key]={'value':value,'status':('unknown' if value is None else status),'source':'user input'}
  if value is None: result='UNKNOWN'; missing.append(f['question'])
  elif status=='disputed': result='DISPUTED'; disputed.append(f['label'])
  else:
   passed={'age':lambda: value>=18,'state':lambda: value.strip().lower() in ('madhya pradesh','mp'),'income':lambda: value<=300000,'identity':lambda: value is True,'disqualified':lambda: value is False}[key]()
   result='TRUE' if passed else 'FALSE'
  trace.append({'rule_id':r['id'],'name':r['name'],'source':r['source'],'expression':r['expression'],'fact':key,'value':value,'fact_status':facts[key]['status'],'result':result,'category':r['category']})
 # Outside validity period is an unresolved applicability issue, never definitive.
 application_date=body.get('application_date') or datetime.date.today().isoformat()
 try: date=datetime.date.fromisoformat(application_date)
 except (ValueError,TypeError): raise ValueError('Enter a valid application date.')
 review_reasons=[]
 if date < datetime.date(2026,1,1): review_reasons.append('No approved demonstration rule version covers this application date.')
 if disputed: review_reasons.append('Material facts are disputed: '+', '.join(disputed)+'.')
 if body.get('legal_uncertainty'): review_reasons.append('User flagged an unresolved legal or interpretive issue.')
 if review_reasons: outcome='REVIEW_REQUIRED'
 elif any(t['result']=='FALSE' for t in trace): outcome='NOT_ELIGIBLE_ON_PROVIDED_FACTS'
 elif missing: outcome='MORE_INFORMATION_NEEDED'
 else: outcome='POTENTIALLY_ELIGIBLE'
 return {'outcome':outcome,'facts':facts,'trace':trace,'missing_questions':missing,'review_reasons':review_reasons,'application_date':application_date,'rule_version':'demo-1.0.0','effective_from':'2026-01-01','source':'Fictional Scheme for Research Demonstration, §§ 3–4','notice':'Fictional rules only. This is not Indian law, legal advice, or an official decision. Facts are user assertions and have not been independently verified.'}

class Handler(BaseHTTPRequestHandler):
 def send(self,status,data,typ='application/json; charset=utf-8'):
  b=(json.dumps(data,ensure_ascii=False) if not isinstance(data,(bytes,str)) else data).encode() if not isinstance(data,bytes) else data
  self.send_response(status); self.send_header('Content-Type',typ); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(b)
 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/':
   with open(os.path.join(ROOT,'index.html'),'rb') as f: self.send(200,f.read(),'text/html; charset=utf-8')
  elif path=='/api/config': self.send(200,{'facts':FACTS,'rules':RULES})
  elif path=='/api/assessments':
   with db() as c: rows=c.execute('SELECT * FROM assessments ORDER BY created_at DESC LIMIT 200').fetchall()
   self.send(200,[{'id':r['id'],'created_at':r['created_at'],'payload':json.loads(r['payload']),'result':json.loads(r['result']),'review_status':r['review_status'],'review_note':r['review_note']} for r in rows])
  elif path=='/api/audit':
   with db() as c: rows=c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 300').fetchall()
   self.send(200,[dict(r) for r in rows])
  else: self.send(404,{'error':'Not found'})
 def do_POST(self):
  path=urlparse(self.path).path
  try:
   length=int(self.headers.get('Content-Length',0))
   if length>100000: raise ValueError('Request too large.')
   body=json.loads(self.rfile.read(length) or b'{}')
   if path=='/api/assess':
    result=evaluate(body); ident=str(uuid.uuid4()); timestamp=now(); review='pending' if result['outcome']=='REVIEW_REQUIRED' else 'not_required'
    with LOCK, db() as c:
     c.execute('INSERT INTO assessments VALUES(?,?,?,?,?,?)',(ident,timestamp,json.dumps(body),json.dumps(result),review,''))
     c.execute('INSERT INTO audit(at,event,assessment_id,details) VALUES(?,?,?,?)',(timestamp,'ASSESSMENT_CREATED',ident,json.dumps({'outcome':result['outcome'],'rule_version':result['rule_version']})))
    self.send(200,{'id':ident,'created_at':timestamp,'result':result,'review_status':review})
   elif path=='/api/review':
    ident=body.get('id'); note=str(body.get('note','')).strip(); status=body.get('status')
    if status not in ('pending','resolved','escalated') or not note or len(note)>3000: raise ValueError('A review note and valid status are required.')
    with LOCK, db() as c:
     row=c.execute('SELECT review_status FROM assessments WHERE id=?',(ident,)).fetchone()
     if not row: self.send(404,{'error':'Assessment not found'}); return
     c.execute('UPDATE assessments SET review_status=?,review_note=? WHERE id=?',(status,note,ident))
     c.execute('INSERT INTO audit(at,event,assessment_id,details) VALUES(?,?,?,?)',(now(),'REVIEW_RECORDED',ident,json.dumps({'from':row['review_status'],'to':status,'note':note})))
    self.send(200,{'ok':True})
   else: self.send(404,{'error':'Not found'})
  except (ValueError,TypeError,json.JSONDecodeError) as e: self.send(400,{'error':str(e)})
  except Exception as e: print('Server error:',repr(e)); self.send(500,{'error':'An internal error occurred.'})
 def log_message(self,format,*args): print('%s %s'%(self.address_string(),format%args))

if __name__=='__main__':
 init(); print('Legal Workbench running on :8000',flush=True); ThreadingHTTPServer(('0.0.0.0',8000),Handler).serve_forever()

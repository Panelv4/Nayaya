# One thing to do before you push

The commits are authored as `NYAYA-RAC <noreply@example.invalid>` because the
sandbox has no GitHub identity. GitHub will show those commits as unattributed —
not linked to your profile.

Fix it with your own details, in one command per commit:

```bash
cd nyaya-repo
git config user.name  "Your Name"
git config user.email "you@users.noreply.github.com"   # or your GitHub email
git rebase --root --exec 'git commit --amend --no-edit --reset-author'
```

That rewrites all three commits to your authorship. **The file contents do not
change** — verified: the tree hash is identical before and after, so everything in
the README and `demo_out/` still matches the committed code.

Then push:

```bash
gh repo create nyayacode --public --source=. --remote=origin --push
# or: git remote add origin https://github.com/<you>/nyayacode.git && git push -u origin main
```

If you have already pushed, the rewrite needs a force-push
(`git push --force-with-lease`), which is safe here: the commit is minutes old and
nobody has pulled it.

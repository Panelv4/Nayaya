# Publishing this repository

The history is clean and the tree is ready. Three ways to get it onto GitHub,
depending on what you have available.

The three commits are already made; you do not need to recreate them. Nothing
here contains a database, an evidence file or a credential — `.gitignore`, the CI
check and the audit below all enforce that.

---

## Option 1 — GitHub CLI (easiest, if `gh` is installed and authenticated)

```bash
cd nyaya-repo
gh auth status                      # confirm you are signed in
gh repo create nyayacode --public --source=. --remote=origin --push \
  --description "Rules-as-code statute analysis: encode a law, find the gaps, measure an amendment"
```

That creates `github.com/<you>/nyayacode`, adds the remote and pushes `main`.

---

## Option 2 — create the repo in the browser, then push over HTTPS

1. Create an **empty** repository named `nyayacode` at
   <https://github.com/new>. Do **not** initialise it with a README, licence or
   `.gitignore` — this tree already has all three and the push would conflict.
2. Then:

```bash
cd nyaya-repo
git remote add origin https://github.com/<your-username>/nyayacode.git
git branch -M main
git push -u origin main
```

Use a **personal access token** as the password when Git asks (GitHub no longer
accepts account passwords over HTTPS). Create one with `repo` scope at
<https://github.com/settings/tokens>.

---

## Option 3 — SSH, if you already have a key on GitHub

```bash
cd nyaya-repo
git remote add origin git@github.com:<your-username>/nyayacode.git
git push -u origin main
```

---

## After the push

1. **Check the Actions tab.** CI runs on Python 3.10 and 3.12: pack check,
   43 library tests, 119 portal tests, then seeds a demo database, starts the
   portal and runs 135 smoke checks against it.
2. **Add topics** so people find it: `law`, `rules-as-code`, `legal-tech`,
   `statute`, `python`, `india`, `bharatiya-nyaya-sanhita`.
3. **Pin the result.** The description and the README both lead with the 256-case
   amendment result; that is the claim worth testing.
4. **Expect the right objection.** The first serious reply will be "who verified
   the encoding?". The answer is in the README: nobody yet, the packs say
   `encoded_unreviewed`, and a passing analysis proves internal consistency rather
   than legal correctness. Saying that first is what makes the rest credible.

---

## If you would rather I pushed it

I cannot: there is no GitHub app connected to this conversation, and I will not
ask for a personal access token in chat — a token pasted into a conversation is a
leaked token. Two better routes:

- run one of the commands above yourself (Option 1 is a single line), or
- connect GitHub to this conversation through the app connectors, and I will push
  it and fix anything CI turns up.

## What is in the repository

```
53 files, 2 commits, no binaries except one screenshot in demo_out/
```

Audited before committing:

- no `*.sqlite3`, no `evidence/`, no `.nyaya-admin-credentials` (gitignored, and CI
  fails the build if any of them ever becomes tracked);
- no real personal data — the development database held two real-looking Gmail
  addresses, three case narratives and nine evidence files, and none of it is here;
  `python3 seed.py` builds an equivalent-shaped database from `@example.invalid`
  accounts instead;
- the live administrator password appears in no file;
- the only email addresses are `@example.invalid`, `@nyaya.test`, `@nyaya.local`
  and one HTML placeholder.
